function openSimple() {
    window.open("http://www.google.com.br", "_blank");
}
function openWindow() {
    window.open("http://www.google.com.br", "_blank", "width=350, height=400, menubar=no, scrollbars=no");
}
function openWindow32() {
    window.open("http://www.google.com.br", "_blank", "width=300, height=200, menubar=yes, scroolbars=yes, location=no, toolbar=no");
}